package skb.TpsGw;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TpsGwApplication {

	public static void main(String[] args) {
		SpringApplication.run(TpsGwApplication.class, args);
	}

}
